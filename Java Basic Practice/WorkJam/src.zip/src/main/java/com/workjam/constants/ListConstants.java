package main.java.com.workjam.constants;

public interface ListConstants {
    int ADMIN_UPPER_BOUND = 5;
    int LOWER_BOUND = 0;
    int EMPLOYEE_UPPER_BOUND = 5;
    int MANAGER_UPPER_BOUND = 5;
}
